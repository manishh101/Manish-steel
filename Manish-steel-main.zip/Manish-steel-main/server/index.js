/**
 * Server entry point for Vercel Serverless
 */

// Export the app from server.js for Vercel
module.exports = require('./server');
